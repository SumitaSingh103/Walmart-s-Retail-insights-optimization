use final_project;
select*from walmartsales;

-- Task 4: Detecting Anomalies in Sales Transactions

-- Step 1: Select key columns from the main table (walmartsales) and join with product line statistics

SELECT 
    w.`Invoice ID`,
    w.`Product line`,
    w.Total,
    
-- Step 2: Include average and standard deviation for that product line

    ROUND(p.AvgTotal, 2) AS AvgTotal,
    ROUND(p.StdDevTotal, 2) AS StdDev,
    
-- Step 3: Define the anomaly type based on comparison with average ± 2*standard deviation

    CASE 
        WHEN w.Total > p.AvgTotal + 2 * p.StdDevTotal THEN 'High Anomaly'
        WHEN w.Total < p.AvgTotal - 2 * p.StdDevTotal THEN 'Low Anomaly'
        ELSE 'Normal'
    END AS AnomalyType
    
-- Step 4: From main sales table aliased as "w"

FROM 
    walmartsales w
    
-- Step 5: Join with a subquery (aliased as "p") that calculates average and stddev for each product line

JOIN (
    SELECT 
        `Product line`, 
        AVG(Total) AS AvgTotal,
        STDDEV(Total) AS StdDevTotal
    FROM 
        walmartsales
    GROUP BY 
        `Product line`
) p
ON w.`Product line` = p.`Product line`;


