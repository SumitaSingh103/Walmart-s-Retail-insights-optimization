
-- Task 3: Analyzing Customer Segmentation Based on Spending  

-- Step 1: Calculate total spending per customer

WITH CustomerSpending AS (
  SELECT 
    `Invoice ID` AS CustomerID,
    SUM(Total) AS TotalSpent
  FROM 
    walmartsales
  GROUP BY 
    `Invoice ID`
),

-- Step 2: Segment customers into 3 spending tiers

CustomerSegmentation AS (
  SELECT 
    CustomerID,
    TotalSpent,
    NTILE(3) OVER (ORDER BY TotalSpent DESC) AS SpendTier
  FROM 
    CustomerSpending
)

-- -- Step 3: Assign spending category label based on the tier

SELECT 
  CustomerID,
  TotalSpent,
  CASE 
    WHEN SpendTier = 1 THEN 'High'
    WHEN SpendTier = 2 THEN 'Medium'
    ELSE 'Low'
  END AS SpendingCategory
FROM 
  CustomerSegmentation;
