select*from walmartsales;

-- Task 10: Analyzing Sales Trends by Day of the Week 
 
SELECT DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y')) AS Day_of_Week, 
SUM(Total) AS Total_Sales
FROM walmartsales
GROUP BY Day_of_Week
ORDER BY Total_Sales DESC;

    
