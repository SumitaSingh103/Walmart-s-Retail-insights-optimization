select*from walmartsales;

-- Task 9: Finding Top 5 Customers by Sales Volume  

SELECT 
    `Customer ID`,
    ROUND(SUM(Total), 2) AS Total_Spent
FROM 
    walmartsales
GROUP BY 
    `Customer ID`
ORDER BY 
    Total_Spent DESC
LIMIT 5;
