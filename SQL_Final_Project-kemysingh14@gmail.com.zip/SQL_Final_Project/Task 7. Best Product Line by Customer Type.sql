select*from walmartsales;

-- Task 7: Best Product Line by Customer Type 

SELECT `Customer type`, `Product line`,  ROUND(Total_Sales, 2) AS Total_Sales
FROM (
    SELECT `Customer type`, `Product line`, SUM(`Total`) AS Total_Sales,
           ROW_NUMBER() OVER (PARTITION BY `Customer type` ORDER BY SUM(`Total`) DESC) AS rn
    FROM walmartsales
    GROUP BY `Customer type`, `Product line`
) ranked
WHERE rn = 1;