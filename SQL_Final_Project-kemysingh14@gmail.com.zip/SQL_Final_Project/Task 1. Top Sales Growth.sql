WITH monthly_sales AS (
    SELECT 
        Branch,
        DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS month_year,
        SUM(Total) AS total_sales
    FROM 
        walmartsales
    GROUP BY 
        Branch, month_year
        
),
-- Step 2: Use window function to calculate month-over-month growth rate

growth_calc AS (
    SELECT
        Branch,
        month_year,
        total_sales,
        LAG(total_sales) OVER (PARTITION BY Branch ORDER BY month_year) AS prev_sales
    FROM 
        monthly_sales
),
-- Step 3: Calculate growth rate and filter out NULLs (first month has no previous month to compare)

growth_rate AS (
    SELECT 
        Branch,
        month_year,
        ((total_sales - prev_sales) / prev_sales) AS growth_rate
    FROM 
        growth_calc
    WHERE 
        prev_sales IS NOT NULL
)
-- Step 4: Get average growth rate and find the top branch

SELECT 
    Branch,
    ROUND(AVG(growth_rate) * 100, 2) AS avg_monthly_growth_percent
FROM 
    growth_rate
GROUP BY 
    Branch
ORDER BY 
    avg_monthly_growth_percent DESC
LIMIT 1;





