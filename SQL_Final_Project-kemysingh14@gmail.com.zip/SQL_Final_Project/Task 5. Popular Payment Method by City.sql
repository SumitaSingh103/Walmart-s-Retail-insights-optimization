use final_project;
select*from walmartsales;

-- Task 5: Most Popular Payment Method by City 

-- Step 1: Count how many times each payment method was used per city
-- Step 2: Rank them within each city by usage count (most used = rank 1)
-- Step 3: Filter only the top-ranked payment method for each city

SELECT 
    City,
    Payment,
    Payment_Count
FROM (
    SELECT 
        City,
        Payment,
        COUNT(*) AS Payment_Count,
        ROW_NUMBER() OVER (PARTITION BY City ORDER BY COUNT(*) DESC) AS rn
    FROM 
        walmartsales
    GROUP BY 
        City, Payment
) ranked
WHERE 
    rn = 1;
