-- Task 2: Finding the Most Profitable Product Line for Each Branch  

-- Step 1: Calculate total profit by product line and branch
WITH product_line_profit AS (
    SELECT
        Branch,
        `Product line`,
        SUM(`gross income`) AS total_profit
    FROM
        walmartsales
    GROUP BY
        Branch, `Product line`
),

-- Step 2: Rank product lines by profit within each branch
ranked_product_lines AS (
    SELECT
        Branch,
        `Product line`,
        total_profit,
        RANK() OVER (PARTITION BY Branch ORDER BY total_profit DESC) AS rn
    FROM
        product_line_profit
)

-- Step 3: Select the top product line for each branch
SELECT
    Branch,
    `Product line` AS most_profitable_product_line,
    ROUND(total_profit, 2) AS total_profit
FROM
    ranked_product_lines
WHERE
    rn= 1;
