select*from walmartsales;

-- Task 6: Monthly Sales Distribution by Gender  

SELECT 
 MONTH(`Date`) AS Month,
    `Gender`,
      ROUND(SUM(Total), 2) AS Total_Sales
FROM walmartsales
GROUP BY MONTH(`Date`), `Gender`
ORDER BY Month, `Gender`;



