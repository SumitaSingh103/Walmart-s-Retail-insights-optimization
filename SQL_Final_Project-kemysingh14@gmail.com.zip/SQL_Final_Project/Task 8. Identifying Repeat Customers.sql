select*from walmartsales;
-- Task 8: Identifying Repeat Customers 
SELECT 
    a.`Invoice ID` AS First_Invoice,
    b.`Invoice ID` AS Repeat_Invoice,
    a.`Date` AS First_Date,
    b.`Date` AS Repeat_Date,
    a.`Customer ID`
FROM 
    walmartsales a
JOIN 
    walmartsales b
ON 
    a.`Customer ID` = b.`Customer ID`
    AND b.`Date` > a.`Date`
    AND DATEDIFF(b.`Date`, a.`Date`) <= 30
ORDER BY 
    a.`Customer ID`, a.`Date`;



